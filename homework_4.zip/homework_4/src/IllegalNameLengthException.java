public class IllegalNameLengthException extends Exception{

    public IllegalNameLengthException(String message) {
        super(message);
    }
}
